/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 *
 * ========================================
*/
#include <project.h>
#include "stdio.h"

// Project Defines.
#define FALSE  0
#define TRUE   1
#define OFF    0
#define ON     1
#define TRANSMIT_BUFFER_SIZE  256

// Variable to store UART received character.
uint8 ch;

// Transmit Buffer. 
char transmitBuffer[TRANSMIT_BUFFER_SIZE];
uint8  outputCounter8  = 0;
uint16 outputCounter16 = 0;
uint32 outputCounter32 = 0;
uint8 flagPrint             = FALSE;
uint8 flagContinuousCounter = FALSE;

const char* strOn  = "ON";
const char* strOff = "OFF";

void printMenu(void){
    // Print Menu.
    sprintf(transmitBuffer, "*****************\r\n");
    // Send out the data.
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  Menu:\r\n");
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  M - Print menu\r\n");
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  0 - Reset counter\r\n");
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  1 - Increment counter\r\n");
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  2 - Start continues counter\r\n");
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  3 - Stop continues counter\r\n");
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  4 - Get switch and LED state\r\n");
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  5 - Set LED on\r\n");
    UART_1_PutString(transmitBuffer);
    sprintf(transmitBuffer, "*  6 - Set LED off\r\n");
    UART_1_PutString(transmitBuffer);
}

int main()
{
    // Start the components.
    UART_1_Start();
        
    // Place your initialization/startup code here (e.g. MyInst_Start()).

    
    CyGlobalIntEnable; // Enable global interrupts.

    // Send message to verify COM port is connected properly.
    UART_1_PutString("COM Port Open 115200bps\r\n");
    printMenu();
    
    for(;;){
        // Place your application code here.
        
        // Non-blocking call to get the latest data recieved.
        ch = UART_1_GetChar();
        
        char* switchRes;
        char* LEDRes;
        
        switch(ch){
            case 0:
                // No new data was recieved.
                break;
            case 'M':
            case 'm':
                // Print Menu.
                printMenu();
                break;
            case '0':
                // Reset counter.
                outputCounter8  = 0;
                outputCounter16 = 0;
                outputCounter32 = 0;
                flagPrint = TRUE;
                break;
            case '1':
                // Print value.
                flagPrint = TRUE;
                break;
            case '2':    
                flagContinuousCounter = TRUE;
                break;
            case '3':
                flagContinuousCounter = FALSE;
                break;
            case '4':
                // The switch is active low.
                if (!Pin_1_Switch_Read())
                    switchRes = (char*) strOn;
                else
                    switchRes = (char*) strOff;
                if (Pin_2_LED_Read())
                    LEDRes = (char*) strOn;
                else
                    LEDRes = (char*) strOff;
                
                sprintf(transmitBuffer, "Switch: %s, LED: %s\r\n",
                    switchRes, LEDRes );
                UART_1_PutString(transmitBuffer);                
                break;
            case '5':
                Pin_2_LED_Write(ON);
                sprintf(transmitBuffer, "LED is ON.\r\n");
                UART_1_PutString(transmitBuffer);
                break;    
            case '6':
                Pin_2_LED_Write(OFF);
                sprintf(transmitBuffer, "LED is OFF.\r\n");
                UART_1_PutString(transmitBuffer);
                break;

            default:
                // Place error handling code here.
                break;    
        }

        if (flagContinuousCounter || flagPrint){
            // Format string of allcounters.
            sprintf(transmitBuffer, "counter_8: %u, counter_16: %u, counter_32: %lu,\r\n",
                outputCounter8, outputCounter16, outputCounter32 );
            // Send out the data. 
            UART_1_PutString(transmitBuffer);
            outputCounter8++;
            outputCounter16++;
            outputCounter32++;
            flagPrint = FALSE;
        }
        
        // The switch is active low.
        if (!Pin_1_Switch_Read()){
            sprintf(transmitBuffer, "Switch is ON!\r\n");
            UART_1_PutString(transmitBuffer);
        }
        
    }
}

// END OF FILE.
